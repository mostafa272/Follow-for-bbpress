=== Follow bbPress ===
Contributors: Mostafa Shahiri
Tags: bbpress , follow, user, topic, shortcode, follower
Requires at least: 4.5.1
Tested up to: 5.2.4
Stable tag: 5.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Follow for bbPress provides a users following system for bbPress.

== Description ==

The Follow for bbPress is a simple following system for bbPress plugin. It provides a very easy and simple way to create a following system for bbPress.
Users can easily follow/unfollow each other and they can see the topics of followings via wall page.

When you activate Follow for bbPress plugin, information and fields related to this plugin are added to users profile page. These infomation and fields include number
of followers, number of following, follow/unfollow button and followers and followers/following links for displaying the followers/following lists.

By clicking on followers/following links, a list of followers (or following) with follow buttons are shown in a popup window and you can also follow other users
via these lists. This plugin gains AJAX method for following/unfollowing users and loading the followers/following lists to improve the performance of your website.

By using [bbpresswall] shortcode you can easily create a wall of the bbpress topics for users. This wall just displays the topics of the users who you follow them.

**Requirements:**

* bbPress plugin

* Jquery


== Plugin Features ==

   * Displaying the topics of the followings via shortcode

   * Gainig AJAX method

   * Easy to use

   * Customizable setting

   * User follow/unfollow system for bbpress

   * Displaying followers/following lists.


== Plugin Setting ==

 * Show Forum: Select yes if you want to show forum title for the topics in the wall section

 * Show Date: Select yes if you want to show create date of the topics in the wall section

 * Number of users per load: The information of how many users are loaded when you open or scroll down the followers/following lists

 * Number of topics per load: How many topics are loaded per request in the wall setion

 * Limit the length of forum title: You can limit the length of forum title (how many words)

 * Limit the length of topic title: Similar limitation for topic title (how many words)

 * Limit the length of topic description: You can also limit the length of descriptions for each topic

 * Users can unfollow X days after following: To prevent frequent follow/unfollow requests by users, you can determine a waiting time for users




== Installation ==

Upload the Follow for bbPress plugin to your blog, Activate it. Before installing this plugin, make sure you have installed bbPress plugin.

== Screenshots ==

1. Setting page in admin panel.
2. Output in user profile
3. Loading the followers list
4. Display the topics of the following users in the wall section 


== Changelog ==

= 1.0 =
First release
