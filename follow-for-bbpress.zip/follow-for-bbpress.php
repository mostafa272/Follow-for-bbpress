<?php
/*
Plugin Name: Follow for bbPress
Description: This plugin provides the following system for bbPress
Version: 1.0
Author: Mostafa Shahiri<mostafa2134@gmail.com>
Author URI: https://github.com/mostafa272
Text domain: follow-for-bbpress
Copyright 2009  Mostafa Shahiri(email : mostafa2134@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
if ( ! defined('ABSPATH')) exit;  // if direct access
register_activation_hook( __FILE__, 'bbpf_activate');
register_uninstall_hook( __FILE__, 'bbpf_uninstall' );
//create table when you activate the plugin
function bbpf_activate() {
global $wpdb;
$wpdb->query("CREATE TABLE IF NOT EXISTS `bbpress_follow` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `follower_id` bigint(20) UNSIGNED NOT NULL,
  `start_follow` DATETIME NOT NULL,
  PRIMARY KEY (`ID`)
)");

}
//drop table and meta fields
function bbpf_uninstall(){
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS `bbpress_follow`");
$wpdb->query("DELETE FROM {$wpdb->prefix}usermeta WHERE meta_key IN('bbpress_followers','bbpress_following')");
}
//load language file
add_action( 'plugins_loaded','bbpf_load_textdomain' );
 function bbpf_load_textdomain() {
	  load_plugin_textdomain( 'follow-for-bbpress', false, plugin_basename( dirname( __FILE__ ) ) . '/languages/' );
	}

//ajax callbacks for following user
add_action( 'wp_ajax_bbpf_follow', 'bbpf_follow_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_follow', 'bbpf_follow_ajax_callback');
 //ajax callbacks for unfollowing user
 add_action( 'wp_ajax_bbpf_unfollow', 'bbpf_unfollow_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_unfollow', 'bbpf_unfollow_ajax_callback');
 ////ajax callbacks for loading the following list
 add_action( 'wp_ajax_bbpf_following_list', 'bbpf_following_list_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_following_list', 'bbpf_following_list_ajax_callback');
 //ajax callbacks for loading the follower list
 add_action( 'wp_ajax_bbpf_follower_list', 'bbpf_follower_list_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_follower_list', 'bbpf_follower_list_ajax_callback');
 //ajax callbacks for following user from loaded list
 add_action( 'wp_ajax_bbpf_follow_from_list', 'bbpf_follow_from_list_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_follow_from_list', 'bbpf_follow_from_list_ajax_callback');
 //ajax callbacks to update bbpress user profile page
  add_action( 'wp_ajax_bbpf_update_user_profile', 'bbpf_update_user_page_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_update_user_profile', 'bbpf_update_user_page_ajax_callback');
 //ajax callbacks for loading the wall topics
 add_action( 'wp_ajax_bbpf_get_wall_topics', 'bbpf_get_wall_topics_ajax_callback' );
 add_action( 'wp_ajax_nopriv_bbpf_get_wall_topics', 'bbpf_get_wall_topics_ajax_callback');
 //loading helper functions to do main operations on data from database are in there
require_once( plugin_dir_path(__FILE__).'helper.php');


add_action( 'wp_enqueue_scripts', 'bbpf_frontend_scripts' );

/**
 * Add our JS and CSS files
 */
function bbpf_frontend_scripts() {
  wp_enqueue_script( 'bbpf-frontend-script', plugins_url( 'js/script.js', __FILE__ ),array('jquery'),'1.0',false );
  wp_enqueue_style( 'bbpf-frontend-style', plugins_url( 'css/style.css', __FILE__ ) );
  wp_localize_script( 'bbpf-frontend-script', 'bbpf_ajax_url', array( 'ajax_url' => admin_url('admin-ajax.php'),'check_nonce'=>wp_create_nonce('bbpf-nonce')) );

}
//setting page and shortcode
require_once( plugin_dir_path(__FILE__).'setting.php');
require_once( plugin_dir_path(__FILE__).'shortcode.php');
//adding the following box to user profile page
add_action('bbp_template_after_user_profile','bbpf_display_follow_box');
function bbpf_display_follow_box(){
$bbp = bbpress();
$user_id = get_current_user_id();
$field = get_option( 'bbpf_field' );

$user_num_limit = (!empty($field['user_num_limit']))? intval($field['user_num_limit']):5;
$allowed = 1;
  if(!empty($user_id))
  {
      $follow_info = array_map( function( $a ){ return $a[0]; }, get_user_meta( $bbp->displayed_user->ID ) );
    $followers_count = (!empty($follow_info['bbpress_followers']))? intval($follow_info['bbpress_followers']):0;
    $following_count = (!empty($follow_info['bbpress_following']))? intval($follow_info['bbpress_following']):0;
    $current_user_id = ($bbp->displayed_user->ID == $user_id)? $user_id:0;
    $output ='<div class="follow_box_container">';
    $output .= '<div class="bbpf_followers" ><a class="bbpf_followers_link" href="#" data-popup-open="follower_popup"  >'.__('Followers:','follow-for-bbpress').'</a> '.$followers_count.'</div>';
    $output .= '<div class="bbpf_following" ><a class="bbpf_following_link" href="#" data-popup-open="following_popup"  >'.__('Following:','follow-for-bbpress').'</a> '.$following_count.'</div>';
    $output .= '<div class="popup bbpf_follower_list" data-popup="follower_popup" data-user_id="'.$bbp->displayed_user->ID.'" data-item_limit="'.$user_num_limit.'">
       <div class="popup-inner">
       <div class="popup-header" >
	    <h4>'.__('Followers','follow-for-bbpress').'</h4>
        <a class="popup-close" data-popup-close="follower_popup" data-user_id="'.$current_user_id.'" href="#">x</a>
        </div>
		<div class="bbpf_view_list"></div>
        <div class="fb_load_container"><div class="lds-facebook"><div></div><div></div><div></div></div></div>
	</div>
</div>
<div class="popup bbpf_following_list" data-popup="following_popup" data-user_id="'.$bbp->displayed_user->ID.'" data-item_limit="'.$user_num_limit.'">
       <div class="popup-inner">
       <div class="popup-header" >
	    <h4>'.__('Following','follow-for-bbpress').'</h4>
        <a class="popup-close" data-popup-close="following_popup" href="#">x</a>
        </div>
        <div class="bbpf_view_list"></div>
        <div class="fb_load_container"><div class="lds-facebook"><div></div><div></div><div></div></div></div>
	</div>
</div>';
    if($bbp->displayed_user->ID!= $user_id)
    {
     //check the following state
     $follow_item = bbpf_is_follow($bbp->displayed_user->ID,$user_id);

      if(!empty($field['unfollow_limit']) && $follow_item)
      {
       $now = strtotime("now");
       $deadline = strtotime( $follow_item->start_follow ) + (intval($field['unfollow_limit'])*86400);
       if($now < $deadline)
       $allowed = 0;
      }
    if($allowed==1)
    {
    if($follow_item && $bbp->displayed_user->ID)
    $output .= '<div class="bbpf_load_container"><div class="fb_load_container"><div class="lds-facebook"><div></div><div></div><div></div></div></div><button class="bbpf_unfollow" data-user_id="'.$bbp->displayed_user->ID.'" >'.__('Unfollow','follow-for-bbpress').'</button></div>';
    else
    $output .= '<div class="bbpf_load_container"><div class="fb_load_container"><div class="lds-facebook"><div></div><div></div><div></div></div></div><button class="bbpf_follow" data-user_id="'.$bbp->displayed_user->ID.'" >'.__('Follow','follow-for-bbpress').'</button></div>';
    }
    else
    {
     $output .= '<div class="bbpf_msg_unfollow">'.__('You are following this user but you can not unfollow him at this time','follow-for-bbpress').'</div>';
    }

    }

    $output .='</div>';
    echo $output;
  }

}




