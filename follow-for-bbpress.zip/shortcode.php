<?php
if ( !defined('ABSPATH')) exit;
//callback function of shortcode for topics
function bbpf_wall_makeshortcode($atts) {
//add script and style files
wp_enqueue_script('bbpf-frontend-script');
wp_enqueue_style('bbpf-frontend-style');
//get attributes for shortcode
$field = get_option( 'bbpf_field' );
$tmp_show_forum = isset($field['show_forum'])? $field['show_forum']:1;
$tmp_show_date = isset($field['show_date'])? $field['show_date']:1;
$tmp_word_limit = !empty($field['word_limit'])? $field['word_limit']:20;
$tmp_item_limit = !empty($field['item_limit'])? $field['item_limit']:5;
$tmp_forum_limit = !empty($field['forum_limit'])? $field['forum_limit']:5;
$tmp_title_limit = !empty($field['title_limit'])? $field['title_limit']:5;
$attr = shortcode_atts( array('show_forum'=>$tmp_show_forum,'show_date'=>$tmp_show_date,'word_limit'=>$tmp_word_limit,'item_limit'=>$tmp_item_limit,'forum_limit'=>$tmp_forum_limit,'title_limit'=>$tmp_title_limit), $atts );
//checking sent values

$show_forum=intval(sanitize_text_field($attr['show_forum']));
$word_limit=intval(sanitize_text_field($attr['word_limit']));
$forum_limit=intval(sanitize_text_field($attr['forum_limit']));
$title_limit=intval(sanitize_text_field($attr['title_limit']));
$item_limit=intval(sanitize_text_field($attr['item_limit']));
$show_date=intval(sanitize_text_field($attr['show_date']));

$output ='';

$user_id = get_current_user_id();
if(!empty($user_id))
{
//get the topics of current user from database
$topics = bbpf_get_topics_info($user_id,$item_limit);

 if(!empty($topics))
 {
   $output = '<div class="bbpf_topic_container" >';
   foreach($topics as $topic)
   {
      $limited_topic_title = wp_trim_words($topic['topic_title'],$title_limit,'...');
     $f_tmp=($show_forum==1)?'<div class="bbpf_topic_forum">'.__('Forum','follow-for-bbpress').': <a href="'.esc_url($topic['forum_url']).'" >'.wp_trim_words($topic['forum_title'],$forum_limit,'...').'</a></div>':'';
     $d_tmp=($show_date==1)?'<div class="bbpf_topic_date">'.__('Date','follow-for-bbpress').': '.$topic['date'].'</div>':'';
     $info_block=(!empty($f_tmp.$d_tmp))?'<div class="bbpf_topic_infoblock">'.$f_tmp.$d_tmp.'</div>':'';
      $output .='<div class="bbpf_topic_item" >';
      $output .= '<div class="bbpf_topic_header" ><a class="bbpf_img_link" href="'.esc_url($topic['profile_url']).'"><img src="'.esc_url($topic['avatar_url']).'" title="'.$topic['display_name'].'" alt="'.$topic['display_name'].'"/></a><a class="bbpf_user_link" href="'.esc_url($topic['profile_url']).'">'.$topic['display_name'].'</a></div>';
     $output .= '<div class="bbpf_topic_title"><a href="'.esc_url($topic['topic_url']).'" >'.$limited_topic_title.'</a></div>';
     $output .= $info_block;
     $output .= '<div class="bbpf_topic_content"><p>'.wp_trim_words($topic['content'],$word_limit,'...').'</p></div>';
     $output .= '<div class="bbpf_topic_read_more"><a class="bbpf_read_more" href="'.esc_url($topic['topic_url']).'" >'.__('Read More','follow-for-bbpress').'</a></div>';
     $output .='</div>';
   }
    //show load more button if topics are more than limitation
    if(count($topics) >= $item_limit)
    {
      $output .= '<div class="bbpf_load_container"><div class="bbpf_loading bbpf_topic_loading" ><div class="bbpf_loader"></div><div class="bbpf_loadtext"> '.__('Loading','follow-for-bbpress').' ...</div></div><button class="bbpf_load bbpf_topic_btn"
    data-show_forum="'.$show_forum.'" data-show_date="'.$show_date.'" data-item_limit="'.$item_limit.'"
   data-word_limit="'.$word_limit.'" data-title_limit="'.$title_limit.'" data-forum_limit="'.$forum_limit.'" > '.__('Load More','follow-for-bbpress').'</button></div>';
    }


   $output .= '</div>';

 }
 else
 {
  $output .= '<div class="bbpf_no_result">'.__('No topics found','follow-for-bbpress').'</div>';
 }

}
else
{
$output = '<div class="bbpf_user_login_msg" >'.__('You must login to see the topics','follow-for-bbpress').'</div>'; 
}
     ob_start();

     echo $output;
     return ob_get_clean();

}

//add shortcode
add_shortcode('bbpresswall','bbpf_wall_makeshortcode');