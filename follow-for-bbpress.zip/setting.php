<?php
if ( ! defined('ABSPATH')) exit;  // if direct access
add_action('admin_menu', 'bbpf_follow_setup_menu');
add_action('admin_init', 'bbpf_follow_register_settings');
add_action( 'admin_enqueue_scripts', 'bbpf_setting_scripts' );
function bbpf_setting_scripts() {

    if ($_GET['page'] != 'follow-for-bbpress') {
        return;
    }
        wp_register_style( 'bbpf-setting-style', plugins_url( 'css/setting-style.css', __FILE__ ) );
}
function bbpf_follow_setup_menu(){
        add_menu_page( 'bbpress Follow', 'bbpress Follow', 'manage_options', 'follow-for-bbpress', 'bbpf_follow_setting_init' );
}
function bbpf_follow_register_settings(){

    register_setting('follow-for-bbpress-settings', 'bbpf_field');

}
function bbpf_follow_setting_init(){
wp_enqueue_style( 'bbpf-setting-style');

if(current_user_can('manage_options'))
{
        echo '<h1>'.__('Follow for bbPress Setting','follow-for-bbpress').'</h1>';
        echo '<form  method="post" action="options.php" >';
         settings_fields( 'follow-for-bbpress-settings' );
      do_settings_sections( 'follow-for-bbpress-settings' );
      $field = get_option( 'bbpf_field' );
    echo '<table class="bbpf_setting_table">
    <tbody>
    <tr><td scope="row"><label>'.__('Show Forum','follow-for-bbpress').'</label></td>
    <td><input type="radio" name="bbpf_field[show_forum]" value="1" '; checked( 1, $field['show_forum']  );
    echo '/>'.__('Yes','follow-for-bbpress');
    echo '<input type="radio" name="bbpf_field[show_forum]" style="margin-left:20px;" value="0" '; checked( 0, $field['show_forum'] );
    echo '/>'.__('No','follow-for-bbpress').'</td></tr>';
    //date
    echo '<tr><td scope="row"><label>'.__('Show Date','follow-for-bbpress').'</label></td>
    <td><input type="radio" name="bbpf_field[show_date]" value="1" '; checked( 1, $field['show_date']  );
    echo '/>'.__('Yes','follow-for-bbpress');
    echo '<input type="radio" name="bbpf_field[show_date]" style="margin-left:20px;" value="0" '; checked( 0, $field['show_date'] );
    echo '/>'.__('No','follow-for-bbpress').'</td></tr>';
    //number of users per load
    $user_num = (empty($field['user_num_limit']))?'5':sanitize_text_field(intval($field['user_num_limit']));
    echo '<tr><td scope="row"><label>'.__('Number of users per load','follow-for-bbpress').'</label></td>';
    echo '<td><input class="bbpf_textbox" type="text" name="bbpf_field[user_num_limit]" value="'.$user_num.'"/></td></tr>';
    $item_limit = (empty($field['item_limit']))?'5':sanitize_text_field(intval($field['item_limit']));
    echo '<tr><td scope="row"><label>'.__('Number of topics per load','follow-for-bbpress').'</label></td>';
    echo '<td><input class="bbpf_textbox" type="text" name="bbpf_field[item_limit]" value="'.$item_limit.'"/></td></tr>';
    //limit the length of forum title
    $forum_limit = (empty($field['forum_limit']))?'5':sanitize_text_field(intval($field['forum_limit']));
    echo '<tr><td scope="row"><label>'.__('Limit the length of forum title','follow-for-bbpress').'</label></td>';
    echo '<td><input class="bbpf_textbox" type="text" name="bbpf_field[forum_limit]" value="'.$forum_limit.'"/></td></tr>';
    //limit the length of topic title
    $title_limit = (empty($field['title_limit']))?'5':sanitize_text_field(intval($field['title_limit']));
    echo '<tr><td scope="row"><label>'.__('Limit the length of topic title','follow-for-bbpress').'</label></td>';
    echo '<td><input class="bbpf_textbox" type="text" name="bbpf_field[title_limit]" value="'.$title_limit.'"/></td></tr>';
    //limit the length of topic description
    $word_limit = (empty($field['word_limit']))?'20':sanitize_text_field(intval($field['word_limit']));
    echo '<tr><td scope="row"><label>'.__('Limit the length of topic description','follow-for-bbpress').'</label></td>';
    echo '<td><input class="bbpf_textbox" type="text" name="bbpf_field[word_limit]" value="'.$word_limit.'"/></td></tr>';

    $unfollow_limit = (empty($field['unfollow_limit']))?'0':sanitize_text_field(intval($field['unfollow_limit']));
    echo '<tr><td scope="row"><span>'.__('Users can unfollow','follow-for-bbpress').'</span>';
    echo '<input class="bbpf_unfollowbox"  type="text" name="bbpf_field[unfollow_limit]" value="'.$unfollow_limit.'"/><span>'.__('days after following','follow-for-bbpress').'</span></td></tr>';

      ?>  <tr><td><?php submit_button('Save') ?>  </td></tr>
                </tbody>
                </table>
        </form>
<?php }
      else {
      echo "You don't have enough permission";
      }
}